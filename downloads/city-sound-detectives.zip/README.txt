City Sound Detectives — FREE book companion
Open City_Sound_Detectives_NARRATED_v2.html in Chrome or Edge. All art, sounds and recorded narration are included for offline use. Teacher tools choose 1–40 turns and three listening modes. Sound must be enabled.
