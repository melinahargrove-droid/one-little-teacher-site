Sky Color Studio — One Little Teacher

Extract this ZIP, then open Sky_Color_Studio_NARRATED.html in a modern browser. Artwork, prerecorded narration, and branding are embedded. An internet connection is only needed to follow the optional website link.

This is an original book-companion activity for Sky Color by Peter H. Reynolds. Choose Paint Our Sky, Sky Detectives, or No Blue Challenge. Teacher tools set class size and artists per painting.

Your gallery and saved session are stored only in this browser. Use Save picture to keep portable PNG copies. The separate Refined ZIP contains editable build source.
